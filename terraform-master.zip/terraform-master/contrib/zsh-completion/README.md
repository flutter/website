# Terraform zsh completion

## Install
```console
% terraform -install-autocomplete
```

## Uninstall
```console
% terraform -uninstall-autocomplete
```
