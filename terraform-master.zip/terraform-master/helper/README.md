# Helper Libraries

This folder contains helper libraries for Terraform plugins. A running
joke is that this is "Terraform standard library" for plugins. The goal
of the packages in this directory are to provide high-level helpers to
make it easier to implement the various aspects of writing a plugin for
Terraform.
